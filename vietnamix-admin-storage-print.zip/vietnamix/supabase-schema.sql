-- Run this SQL in Supabase > SQL Editor.
-- Enable anonymous sign-ins in Authentication > Providers > Anonymous.
create table if not exists public.cart_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id text not null,
  product_name text not null,
  category text not null default '',
  unit_price integer not null check (unit_price >= 0),
  quantity integer not null default 1 check (quantity between 1 and 20),
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete restrict,
  customer_name text not null,
  phone text not null,
  shipping_address text not null,
  note text not null default '',
  items jsonb not null,
  total_amount integer not null check (total_amount >= 0),
  status text not null default 'pending' check (status in ('pending','confirmed','processing','shipped','completed','cancelled')),
  created_at timestamptz not null default now()
);

alter table public.cart_items enable row level security;
alter table public.orders enable row level security;

-- Each anonymous/authenticated customer can access only their own cart.
drop policy if exists "Customers manage own cart" on public.cart_items;
create policy "Customers manage own cart" on public.cart_items
for all to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

-- Customers can create and read only their own orders.
drop policy if exists "Customers create own orders" on public.orders;
create policy "Customers create own orders" on public.orders
for insert to authenticated
with check (auth.uid() = user_id);

drop policy if exists "Customers read own orders" on public.orders;
create policy "Customers read own orders" on public.orders
for select to authenticated
using (auth.uid() = user_id);

create index if not exists cart_items_user_id_idx on public.cart_items(user_id);
create index if not exists orders_user_id_created_idx on public.orders(user_id, created_at desc);


-- PRODUCT CATALOG + ADMIN ACCESS
create table if not exists public.products (
  id text primary key, name text not null, category text not null default '',
  price integer not null check (price >= 0), label text not null default 'NEW DROP',
  color text not null default '#242424', print text not null default '',
  image_url text not null default '', active boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.products enable row level security;
alter table public.admin_users enable row level security;
drop policy if exists "Public can view active products" on public.products;
create policy "Public can view active products" on public.products for select using (active = true);
drop policy if exists "Admins manage products" on public.products;
create policy "Admins manage products" on public.products for all to authenticated
using (exists(select 1 from public.admin_users a where a.user_id = auth.uid()))
with check (exists(select 1 from public.admin_users a where a.user_id = auth.uid()));
drop policy if exists "Admins read admin roster" on public.admin_users;
create policy "Admins read admin roster" on public.admin_users for select to authenticated
using (user_id = auth.uid());
drop policy if exists "Admins read all orders" on public.orders;
create policy "Admins read all orders" on public.orders for select to authenticated
using (exists(select 1 from public.admin_users a where a.user_id = auth.uid()));
drop policy if exists "Admins update orders" on public.orders;
create policy "Admins update orders" on public.orders for update to authenticated
using (exists(select 1 from public.admin_users a where a.user_id = auth.uid()))
with check (exists(select 1 from public.admin_users a where a.user_id = auth.uid()));

-- After creating your admin account in Supabase Auth, run this with its UUID:
-- insert into public.admin_users(user_id) values ('YOUR_AUTH_USER_UUID');

-- STORAGE: public catalog photos + private customer print artwork.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('product-images','product-images',true,8388608,array['image/jpeg','image/png','image/webp']),
  ('design-files','design-files',false,12582912,array['image/png'])
on conflict (id) do update set
  public=excluded.public,
  file_size_limit=excluded.file_size_limit,
  allowed_mime_types=excluded.allowed_mime_types;

-- Product photos are publicly readable; only admins can upload, replace, or delete.
drop policy if exists "Public read product images" on storage.objects;
create policy "Public read product images" on storage.objects for select
using (bucket_id='product-images');
drop policy if exists "Admins upload product images" on storage.objects;
create policy "Admins upload product images" on storage.objects for insert to authenticated
with check (bucket_id='product-images' and exists(select 1 from public.admin_users a where a.user_id=auth.uid()));
drop policy if exists "Admins update product images" on storage.objects;
create policy "Admins update product images" on storage.objects for update to authenticated
using (bucket_id='product-images' and exists(select 1 from public.admin_users a where a.user_id=auth.uid()))
with check (bucket_id='product-images' and exists(select 1 from public.admin_users a where a.user_id=auth.uid()));
drop policy if exists "Admins delete product images" on storage.objects;
create policy "Admins delete product images" on storage.objects for delete to authenticated
using (bucket_id='product-images' and exists(select 1 from public.admin_users a where a.user_id=auth.uid()));

-- Customer artwork is private and stored under a folder named with the customer's auth UUID.
drop policy if exists "Owners upload own design files" on storage.objects;
create policy "Owners upload own design files" on storage.objects for insert to authenticated
with check (bucket_id='design-files' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "Owners and admins read design files" on storage.objects;
create policy "Owners and admins read design files" on storage.objects for select to authenticated
using (bucket_id='design-files' and ((storage.foldername(name))[1]=auth.uid()::text or exists(select 1 from public.admin_users a where a.user_id=auth.uid())));
