# VIETNAMIX storefront

A responsive static storefront and custom T-shirt editor. GitHub Pages hosts the frontend; Supabase provides anonymous customer sessions, persistent carts, and order records.

## 1. Run locally

Open `index.html` in a modern browser. Without Supabase credentials, product browsing and the shirt editor work, while cart/order persistence remains demo-only.

## 2. Configure Supabase

1. Create a project at https://supabase.com.
2. In **Authentication → Providers**, enable **Anonymous Sign-Ins**.
3. Open **SQL Editor**, paste and run `supabase-schema.sql`.
4. In **Project Settings → API**, copy the Project URL and `anon` / publishable key.
5. In `script.js`, replace:
   - `YOUR_SUPABASE_URL`
   - `YOUR_SUPABASE_ANON_KEY`
6. Never put a `service_role` or secret key in browser JavaScript.

The database uses Row Level Security and anonymous Supabase Auth. Cart rows are scoped to the authenticated user. Orders can be inserted/read by their owner; admins can read and update orders. Storage includes a public `product-images` bucket (admin writes only) and a private `design-files` bucket (customers upload/read their own files; admins can read files for order production). For production, validate prices and order contents on a trusted server/Edge Function and add rate limiting/CAPTCHA before accepting payments.

## 3. Publish with GitHub Pages

1. Create a GitHub repository, e.g. `vietnamix`.
2. Upload `index.html`, `style.css`, `script.js`, and `supabase-schema.sql` to the repository root.
3. Commit and push the files.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch `main` and folder `/ (root)`, then Save.
7. Wait for GitHub Pages to publish; open the URL shown on that settings page.

After editing files, commit and push again; Pages will redeploy automatically.

## Current scope / important limitations

- Product catalog and prices in `script.js` are sample data.
- Custom editor supports shirt color, front/back views, text, local image upload, and pointer-drag positioning. It exports transparent PNG artwork at 1400×1520 px for front/back, and uploads these files to the private `design-files` bucket when adding the design to the cart. Admin can create a time-limited signed link to open the artwork from an order. This is a production handoff asset, not a guarantee of any specific print DPI or physical size; confirm dimensions, color profile, bleed, and print requirements with the print shop.
- NFC is an optional line item in the order. The site does not program NFC tags automatically; tag encoding and the destination experience must be configured separately.
- Checkout records an order request in Supabase; it does not process payment, calculate shipping, or send email/SMS. Admin Dashboard is available at `admin.html`.
- The anon/publishable key is intended for browser use only when RLS is correctly configured. Never expose the service-role key.


## Admin Dashboard (bản nâng cấp)
1. Chạy lại toàn bộ `supabase-schema.sql` trong Supabase SQL Editor để tạo bảng `products`, `admin_users` và chính sách RLS quản trị.
2. Tạo tài khoản quản trị trong Supabase Authentication > Users (email/password).
3. Sao chép UUID của user vừa tạo, thay vào lệnh `insert into public.admin_users(user_id) values ('YOUR_AUTH_USER_UUID');` ở cuối SQL rồi chạy lệnh đó. Không cấp quyền admin cho khách hàng.
4. Điền cùng `SUPABASE_URL` và `SUPABASE_ANON_KEY` vào `script.js` và `admin.js`.
5. Mở `admin.html` để đăng nhập quản trị. Trang cửa hàng sẽ đọc sản phẩm đang hoạt động từ bảng `products`; nếu bảng chưa có dữ liệu, cửa hàng giữ danh mục demo.

**Tải ảnh sản phẩm và file in:** trong `admin.html`, chọn tệp ảnh tại mục Ảnh sản phẩm (PNG/JPG/WebP, tối đa 8MB). Ảnh sản phẩm được lưu trong bucket công khai `product-images`. Trong Custom Studio, dùng nút Tải PNG mặt trước/mặt sau để xuất file cục bộ; khi nhấn Thêm thiết kế vào giỏ, file PNG nền trong suốt được tải lên bucket riêng tư `design-files`. Trong Admin > Đơn hàng > Chi tiết đơn, nhấn Mở file thiết kế PNG để tạo liên kết tạm thời 1 giờ.

Trang admin dùng email/password, còn website khách dùng anonymous auth. Không đưa service_role key vào bất kỳ file trình duyệt nào. Nếu chạy SQL schema cũ trước đây, chạy lại toàn bộ file SQL mới để tạo bucket và các chính sách Storage.
